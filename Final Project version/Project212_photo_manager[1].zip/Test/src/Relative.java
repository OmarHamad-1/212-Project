
public enum Relative {
	Root, Parent, LeftChild, RightChild
}
